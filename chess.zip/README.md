#Final Project for CS246
Key points to keep in mind while using our chess program:
new </player1(computer1/computer    2/computer3/human)> </player2(computer1/computer2/computer3/human)> </setup type (default or manually place all pieces according to assignment rubric)>
If at any point in the game you need to view the Game Analyzer, type in: analyze
After every move, the program will show a list of all the black and white pieces on the board and the bin which contains all the pieces that have been captured/deleted and are no longer part of the game.
To undo a move at any state in the game, simply type in: undo.
Also, if it is a human v/s AI or AI v/s AI game, at each step, information will be printed to the screen about which player is playing. (white AI or black AI)
